package org.muhurta.daily;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView view = new WebView(this);
        view.getSettings().setJavaScriptEnabled(true);
        view.getSettings().setDomStorageEnabled(true);
        view.getSettings().setAllowFileAccess(false);
        view.getSettings().setAllowFileAccessFromFileURLs(false);
        view.getSettings().setAllowUniversalAccessFromFileURLs(false);
        view.setWebViewClient(new WebViewClient());
        view.setWebChromeClient(new WebChromeClient());
        setContentView(view);
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            String bundledHtml = new String(output.toByteArray(), StandardCharsets.UTF_8);
            // Bundle remains offline, but uses a secure HTTPS origin, so fetch()
            // can retrieve the GitHub Pages astronomy JSON via same-origin policy.
            view.loadDataWithBaseURL("https://challaharshavardhan.github.io/SeasonalTimeApp/",
                    bundledHtml, "text/html", "UTF-8", null);
        } catch (Exception ex) {
            view.loadDataWithBaseURL("https://challaharshavardhan.github.io/SeasonalTimeApp/",
                "<html><body>Unable to load bundled Muhurta HTML.</body></html>",
                "text/html", "UTF-8", null);
        }
    }
}
