Muhurta Vishnu – auto-downloaded astronomical data extension

- Original bundled Moon (2024–2036) and Sun coordinates remain unchanged.
- A safety fallback for 2037–2040 is bundled for offline availability.
- On launch with internet, the app fetches muhurta-astronomy-2037-2100.json
  from the same GitHub Pages site, validates it and caches it in WebView localStorage.
- A manual Check for astronomical updates button appears in Settings.
- The calendar selector allows dates through 2100.
- Both solar and lunar data must be published, or no extension beyond 2040 is possible.
- This version installs alongside earlier apps to avoid debug APK signing conflicts.
- When you upload this project ZIP to GitHub, keep folder layout as-is.
- Run the existing Actions workflow with its unzip source changed to
    unzip -q MuhurtaVishnuAutoData.zip -d project
  The existing Gradle project path remains:
    project/Muhurta-Lotus-Black-Glow-Project
- Separately upload muhurta-astronomy-2037-2100.json at the repository ROOT
  (not inside a ZIP) for the live updates to work.
- On website, replace your previous HTML with the new 'vishnu muhurtam web.html'
  and keep the extension JSON in the same folder.
- Code generator can later extend through 2101+ with pyswisseph.
- As currently configured this is NOT perpetual automatic generation beyond 2100.
- Never erase user preferences or previously downloaded data after a failed fetch.
