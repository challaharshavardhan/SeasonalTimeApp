#!/usr/bin/env python3
"""Generate Swiss Ephemeris (Moshier) lunar nakshatra transitions and solar equatorial coordinates.

The payload extends the existing Muhurta HTML's bundled table at its exact anchor.
Requires: pip install pyswisseph
Uses Lahiri sidereal ayanamsa, Meeus convention UTC Unix timestamps.
"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone, timedelta
import json
from pathlib import Path
import swisseph as swe

DAY_S = 86400
N = 27
SPAN = 360.0 / N
MOON_ANCHOR = [2114802183, 10]  # 2037-01-05 21:03:03 UTC, exact built-in table's final record
SOLAR_START_MS = 2114899200000  # 2037-01-07 00:00 UTC, the first UTC day after the built-in Sun table
swe.set_sid_mode(swe.SIDM_LAHIRI)
MOON_FLAGS = swe.FLG_MOSEPH | swe.FLG_SIDEREAL
SUN_FLAGS = swe.FLG_MOSEPH | swe.FLG_EQUATORIAL

def jd(ts):
    return ts / 86400.0 + 2440587.5

def moon_error(ts, target):
    lon = swe.calc_ut(jd(ts), swe.MOON, MOON_FLAGS)[0][0]
    return ((lon - target + 180.0) % 360.0) - 180.0

def next_transition(ts: int, next_index: int) -> int:
    target = next_index * SPAN
    low = ts + 60
    high = low + 12*3600
    if moon_error(low, target) > 0:
        raise ValueError('Moon root bracket starts too late')
    while moon_error(high, target) < 0:
        high += 6*3600
        if high - low > 48*3600:
            raise ValueError('Could not bracket lunar transition')
    # Bisection 27 steps for sub-second precision.
    for _ in range(27):
        mid = (low + high) / 2
        if moon_error(mid, target) < 0:
            low = mid
        else:
            high = mid
    return round((low+high)/2)

def generate(end_year: int):
    if not (2038 <= end_year <= 2300):
        raise ValueError('End year must be 2038–2300')
    # Extend enough beyond December 31 of end_year for time zones and night times.
    # UTC 10 January of next year safely includes spillover.
    through_ts = int(datetime(end_year+1,1,10,tzinfo=timezone.utc).timestamp())
    lunar = []
    ts, index = MOON_ANCHOR
    while ts < through_ts:
        index = (index+1)%27
        ts = next_transition(ts,index)
        lunar.append([ts,index])
    solar = []
    stamp = SOLAR_START_MS//1000
    while stamp <= through_ts:
        val = swe.calc_ut(jd(stamp),swe.SUN,SUN_FLAGS)[0]
        solar.append([round(val[0],6),round(val[1],6)])
        stamp += DAY_S
    return {
        'schema': 1,
        'source': 'Swiss Ephemeris Moshier; Lahiri sidereal Moon; equatorial geocentric Sun',
        'fromYear': 2037,
        'throughYear': end_year,
        'lunar': {'anchor': MOON_ANCHOR, 'records': lunar},
        'solar': {'startMs': SOLAR_START_MS, 'records': solar},
    }

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--end-year', type=int, default=2100)
    parser.add_argument('--output',default='muhurta-astronomy-2037-2100.json')
    args=parser.parse_args()
    data=generate(args.end_year)
    out=Path(args.output)
    out.write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False),encoding='utf-8')
    print(f'Wrote {out} ({out.stat().st_size:,} bytes), through {args.end_year}, '
          f'{len(data["lunar"]["records"])} lunar transitions and {len(data["solar"]["records"])} solar days')
