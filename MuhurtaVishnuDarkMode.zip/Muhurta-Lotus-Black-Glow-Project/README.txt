MUHURTA – VISHNU, LAKSHMI, BRAHMA & BLUE LOTUS ICON

This project uses the exact selected 3D artwork (Lord Vishnu reclining on Adishesha,
Goddess Lakshmi alongside him, and Brahma seated on a blue lotus growing from
Vishnu's navel) for Android's launcher icon. The high-resolution source PNG is
included in app/src/main/assets/vishnu-lakshmi-brahma-artwork.png.

IMPORTANT: The app's original index.html and Java WebView code are preserved.
The launcher resources have been updated for legacy and adaptive Android icons.
The Android application ID is org.muhurta.lotus.vishnu and the display label is
Muhurta Vishnu; installs separately without replacing any of your prior APKs.

PHONE-ONLY GITHUB BUILD:
1. Upload the one ZIP file, Muhurta-Vishnu-Blue-Lotus-Project.zip, to the ROOT
   of your existing GitHub repo SeasonalTimeApp. Do not extract this ZIP.
2. Edit your existing .github/workflows/build-apk.yml. In its Extract project
   step ONLY, replace the unzip line with:
       unzip -q Muhurta-Vishnu-Blue-Lotus-Project.zip -d project
3. LEAVE THE BUILD PATH UNCHANGED. Inside this new ZIP the project root remains
   Muhurta-Lotus-Black-Glow-Project, so the following existing command works:
       gradle --no-daemon -p project/Muhurta-Lotus-Black-Glow-Project assembleDebug
4. Commit to main, open Actions, and download the APK artifact once build is green.
5. Extract the artifact ZIP and install app-debug.apk on your phone.

The display name changes to "Muhurta Vishnu" so you can recognize this test build.
The image is static 3D artwork, not an animated or real 3D model.
Note: final icon appearance is controlled by your Android launcher's mask and
may crop the edges of the art. The exact artwork itself has not been redrawn.
