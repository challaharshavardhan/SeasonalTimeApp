Muhurta Vishnu — Dark mode (Version 1.5)

Built from the previously working MuhurtaVishnu.zip project.
- Settings > Dark mode toggle, with localStorage persistence.
- Quick moon/sun toggle in the Today screen header.
- Sapphire-night colors, high contrast and dark-themed swipeable clocks.
- Original Muhurta formulas, city data, astronomy tables, offline behavior and Vishnu icon are unchanged.
- Separate Android package ID so you can test alongside the working installed app.

GITHUB ACTIONS: Keep the Gradle command, project folder and SDK settings
that already built successfully. Replace only the unzip source with:
 unzip -q MuhurtaVishnuDarkMode.zip -d project
The nested folder remains Muhurta-Lotus-Black-Glow-Project.

The separate app appears as Muhurta Vishnu. If you see two apps
with the same name, the new one has a dark mode toggle in Settings.

Original project remains your backup.
