MUHURTA LOTUS - BLACK / GLOWING GOLD ICON - PHONE BUILD

THIS IS THE SOURCE PROJECT (ZIP), NOT AN APK.
Your original HTML is preserved byte-for-byte.
The native Android launcher icon is now defined in mipmap/round/adaptive Android resources.
The background is near-black and the lotus has an illuminated gold glow.
This package uses ID org.muhurta.lotus.blackglow so your existing Muhurta app is left untouched.

PHONE BUILD WITH CODE ON THE GO
1. Install Code on the Go from https://appdevforall.org/code-on-the-go/
2. Extract this ZIP with Files/Files by Google.
3. Open the extracted Muhurta-Lotus-Black-Glow-Project folder using the IDE's Open Existing Project option.
4. Let the project synchronize and install build dependencies, then use the green Run button to build and install.
5. If your IDE requires a gradle wrapper, use the cloud build method in .github/workflows/build-apk.yml.

NOTE: Static validation only. No Android SDK / phone emulator is available here to test the APK build.
